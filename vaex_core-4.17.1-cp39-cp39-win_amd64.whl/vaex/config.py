import os
import vaex.utils
import pydantic


class ConfigDefault:
    pass
