# https://het.as.utexas.edu/HET/Software/Numpy/reference/arrays.scalars.html
import visions.backends.numpy.types
from visions.backends.numpy.array_utils import array_handle_nulls, array_not_empty
