__version_tuple__ = (1, 0, 0, 'beta.6')
__version__ = '1.0.0-beta.6'
